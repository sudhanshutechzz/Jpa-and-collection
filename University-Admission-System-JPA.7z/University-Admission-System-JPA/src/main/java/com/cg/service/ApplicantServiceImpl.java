package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.Validation.UniversityAdmissionValidation;
import com.cg.dao.Applicantdao;
import com.cg.dao.ApplicantdaoImpl;
import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.Schedule;

public class ApplicantServiceImpl implements ApplicantService {
	Applicantdao adao = new ApplicantdaoImpl();

	@Override
	public List<Courses> viewCourses() {

		return adao.viewCourses();
	}
	
	@Override
	public List<Schedule> viewSchedule() {
		// TODO Auto-generated method stub
		return adao.viewSchedule();
	}

	@Override
	public Applicant applyForCourse(String fullName, String dateOfBirth, String highestQualification,
			float marksObtained, String goals, String emailId,Courses course) {

		return adao.applyForCourse(new Applicant(fullName, dateOfBirth, highestQualification, marksObtained, goals,
				emailId, course));
	}

	@Override
	public Applicant viewStatus(int appId) {

		return adao.viewStatus(appId);
	}

	@Override
	public boolean isValidId(int id) {
		// TODO Auto-generated method stub
		return adao.isValidId(id);
	}


}
