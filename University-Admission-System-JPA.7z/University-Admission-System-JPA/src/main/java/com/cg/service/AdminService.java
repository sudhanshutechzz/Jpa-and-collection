package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.Schedule;

public interface AdminService {
	//?autoReconnect=true&amp;useSSL=false
	public boolean verifyUser(String username,String password,String role);
	public List<Applicant> viewApplicant(String programName);
	public List<Courses> viewCourses();
	public Courses addCourse(String programName,String description,String applicantEligibility,int duration,String degreeCertificateOffered);
	public String deleteCourse(int courseId);
	public String addSchedule(int scheduledProgramId,String programName, String location,String startDate,  String endDate,int sessionsPerWeek );
	public String deleteSchedule(int scheduledProgramId);
	public List<Schedule> viewSchedule();
	public String isValidId2(int id);
	public boolean isValidProgramName(String programName);
	public String isValidScheduleProgramId(int scheduleProgramId);
	public String updateSchedule(int scheduledProgramId,String programName, String location,String startDate,  String endDate,int sessionsPerWeek );
	
}
