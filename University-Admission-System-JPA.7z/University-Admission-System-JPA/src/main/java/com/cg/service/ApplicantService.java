package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.Schedule;

public interface ApplicantService {
	public List<Courses> viewCourses();
	public List<Schedule> viewSchedule();
	public Applicant applyForCourse(String fullName,String dateOfBirth,String highestQualification,float marksObtained,String goals,String emailId,Courses course);
	public Applicant viewStatus(int appId);
	public boolean isValidId(int id);
}
