package com.cg.Validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.cg.dto.Courses;

public class UniversityAdmissionValidation {

    

	 public boolean isValidName(String name)
	    {
	        String namePattern="[A-Z][a-z]{2,20}";
	        if(Pattern.matches(namePattern,name))
	            return true;
	        else
	            return false;
	    }
	    public boolean isValidUserName(String userName)
	    {
	        String userNamePattern="^[a-z0-9_-]{3,15}$";
	        if(Pattern.matches(userNamePattern, userName))
	        return true;
	        else
	        return false;
	    }
	    boolean isValidPassword(String password)
	    {
	        String passwordPattern="((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
	        if(Pattern.matches(passwordPattern, password))
	            return true;
	            else
	            return false;
	    }
	    public boolean isValidEmail(String email)
	    {
	        String emailPattern="[_A-Za-z0-9.]*+@+[A-Za-z][A-Za-z]{4,10}+.+[A-Za-z][A-Za-z]{2,3}";
	        if(Pattern.matches(emailPattern, email))
	            return true;
	        else
	            return false;
	    }
	    public boolean isValidDate(String d) 
	    { 
	        String regex = "^(1[0-2]|0[1-9])/(3[01]"
	                       + "|[12][0-9]|0[1-9])/[0-9]{4}$"; 
	        Pattern pattern = Pattern.compile(regex); 
	        Matcher matcher = pattern.matcher((CharSequence)d); 
	        return matcher.matches(); 
	    }
	    public boolean isValidHighestQualification(String hq)
	    {
	    	if(hq.equalsIgnoreCase("graduation")||hq.equalsIgnoreCase("HSC")||hq.equalsIgnoreCase("SSC"))
	    		return true;
	    	else
	    		return false;
	    }
	    public boolean isValidMarks(float marks)
	    {
	    	if(marks>40&&marks<=100)
	    		return true;
	    	else
	    		return false;
	    }
	    public boolean isValidDuration(int duration)
		{
			if(duration>=2&&duration<=5)
				return true;
			else
				return false;
		}
		public boolean isValidDegree(String degree)
		{
			String degreePattern="[A-Z]{1}[a-zA-Z0-9:,.\\s-]{0,}";
			if (Pattern.matches(degreePattern, degree))
				return true;
			else
				return false;
		}
		
		public boolean isValidDescription(String description)
		{
			String descriptionPattern="[A-Z]{1}[a-zA-Z0-9:,.\\s-]{0,}";
			if (Pattern.matches(descriptionPattern, description))
				return true;
			else
				return false;
		}
		
		public boolean isValidLocation(String location)
		{
			String locationPattern="[A-Z]{1}[a-zA-Z0-9:,.\\s-]{0,}";
			if (Pattern.matches(locationPattern, location))
				return true;
			else
				return false;
		}
		
		public boolean isValidSessions(int sessionsPerWeek)
		{
			if(sessionsPerWeek>=5&&sessionsPerWeek<=7)
				return true;
			else
				return false;
		}
	 



}
