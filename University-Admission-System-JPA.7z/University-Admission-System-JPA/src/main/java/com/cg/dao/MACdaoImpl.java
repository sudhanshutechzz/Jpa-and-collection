package com.cg.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.LogIn;
import com.cg.exception.MyException;
import com.cg.exception.ValidateApplicant;

public class MACdaoImpl implements MACdao {

	EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
	EntityManager em = emf.createEntityManager();

	@Override
	public boolean verifyUser(LogIn login) {

		Iterator<LogIn> itr = em.createQuery("SELECT a FROM LogIn a", LogIn.class).getResultList().iterator();
		while (itr.hasNext()) {
			LogIn obj = itr.next();

			if (login.getUserName().equals(obj.getUserName()) && login.getPassword().equals(obj.getPassword())
					&& login.getRole().equals(obj.getRole())) {
				return true;
			}

		}
		throw new MyException("Invalid Credentials");

	}

	@Override
	public List<Applicant> getApplicantsByCourseId(int courseId) {

		boolean flag = false;

		List<Applicant> list1 = new ArrayList<Applicant>();

		List<Applicant> list = em.createQuery("select a from Applicant a", Applicant.class).getResultList();
		Iterator<Applicant> itr = list.iterator();
		while (itr.hasNext()) {
			Applicant app = itr.next();
			if (app.getCourse().getCourseId() == courseId) {
				list1.add(app);
				flag = true;
			}

		}
		if (flag == true)
			return list1;
		else
			throw new MyException("list does not conatin any applicant record basis on this id");
	}

	@Override
	public String sheduleInterview(int applicant, String date) {
		boolean flag = false;
		Applicant app = em.find(Applicant.class, applicant);
		try {
			if (app != null) {
				if (app.getStatus().equalsIgnoreCase("under process")) {
					em.getTransaction().begin();
					app.setDateOfInterview(date);
					em.getTransaction().commit();
					flag = true;
				} else
					throw new MyException( "Application is already processed");
			}
		} catch (Exception e) {
			throw new MyException("Null value");
		}
		if (flag) {

			return "Interview Scheduled";
		} else {
			throw new MyException( "Applicant id is not found");
		}

	}

	@Override
	public String updateStatus(int applicationId, int status) {
		// TODO Auto-generated method stub
		String statusValue = "";
		List<Applicant> list = em.createQuery("select a from Applicant a", Applicant.class).getResultList();
		Iterator<Applicant> itr = list.iterator();
		while (itr.hasNext()) {
			Applicant app = itr.next();

			if (app.getApplicantId() == applicationId) {
				if (!app.getDateOfInterview().equalsIgnoreCase("not yet finalised")) {
					if (status == 1) {
						statusValue = "Selected";
					} else if (status == 2) {
						statusValue = "Rejected";
					} else {
						statusValue = "On-Hold";
					}
					em.getTransaction().begin();
					app.setStatus(statusValue);
					em.getTransaction().commit();
					return "Status Updated";
				} else
					throw new MyException("firstly schedule an interview");
			}

		}

		throw new MyException("Application does not Exists");
	}
}
