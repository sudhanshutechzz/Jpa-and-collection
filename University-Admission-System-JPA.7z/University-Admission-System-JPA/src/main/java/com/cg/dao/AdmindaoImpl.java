package com.cg.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.LogIn;
import com.cg.dto.Schedule;
import com.cg.exception.MyException;

public class AdmindaoImpl implements Admindao {
	List<Courses> courseList;
	List<Schedule> scheduleList;
	int count=0;
	public EntityManager manager;
	@Override
	public boolean verifyUser(LogIn login) {
		manager=EntityManagerUtil.getEntityManagerFactory().createEntityManager();
		Iterator<LogIn> itr = manager.createQuery("SELECT a FROM LogIn a", LogIn.class).getResultList().iterator();
		while (itr.hasNext()) {
			LogIn obj = itr.next();

			if (login.getUserName().equals(obj.getUserName()) && login.getPassword().equals(obj.getPassword())
					&& login.getRole().equals(obj.getRole())) {
				return true;
			}

		}
		throw new MyException("Invalid Credentials");

	}
	
	@Override
	public List<Applicant> viewApplicant(String programName) {
		manager=EntityManagerUtil.getEntityManagerFactory().createEntityManager();
		int courseId = 0;
		List<Applicant> appList=new ArrayList();
		courseList = manager.createQuery("SELECT a FROM Courses a", Courses.class).getResultList();
		for(Courses course:courseList)
		{
			if(course.getProgramName().equalsIgnoreCase(programName))
			{
				courseId=course.getCourseId();
			}
		}
		for (Applicant applicant : manager.createQuery("SELECT a FROM Applicant a", Applicant.class).getResultList()) {

			if (applicant.getCourse().getCourseId() == courseId) {
				appList.add(applicant);
			}

		}
		manager.close();
		EntityManagerUtil.shutdown();
		if(!appList.isEmpty())
			return appList;
		else
			throw new MyException("No Applicant is enroll in that course");
		
	}

	@Override
	public Courses addCourse(Courses course) {
		manager=EntityManagerUtil.getEntityManagerFactory().createEntityManager();
		courseList= manager.createQuery("SELECT a FROM Courses a", Courses.class).getResultList();
		int id=courseList.size();
		Courses course2=new Courses(id+1,course.getProgramName(),course.getDescription(),course.getApplicantEligibility(),course.getDuration(),course.getDegreeCertificateOffered());
		manager.getTransaction().begin();
		manager.persist(course2);
		manager.getTransaction().commit();
		manager.close();
		EntityManagerUtil.shutdown();
		return course2;
	}

	@Override
	public String deleteCourse(int courseId) {
		manager=EntityManagerUtil.getEntityManagerFactory().createEntityManager();
		count = 0;
		for (Applicant app : manager.createQuery("SELECT a FROM Applicant a", Applicant.class).getResultList()) {
			if (app.getCourse(). getCourseId() == courseId) {
				count++;
			}
		}
		
		if (count == 0) {
			Courses cour = manager.find(Courses.class, courseId);
			if (cour != null) {
				manager.getTransaction().begin();
				manager.remove(cour);
				manager.getTransaction().commit();
				manager.close();
				EntityManagerUtil.shutdown();
				return "Course deleted sucessfully and Make sure you also deleted the schedule for the course";
			}
			else {
				throw new MyException("There is no course for this course Id");
			}
		} else {
			throw new MyException("Cannot delete course because Some Students are already enroll in that course");
		}

	}

	@Override
	public String addSchedule(Schedule schedule) {
		manager=EntityManagerUtil.getEntityManagerFactory().createEntityManager();
		boolean flag = false;
		scheduleList = manager.createQuery("SELECT a FROM Schedule a", Schedule.class).getResultList();
		for (Schedule sched : scheduleList) {
			if (schedule.getScheduledProgramId() == sched.getScheduledProgramId())
				flag = true;
		}
		if (flag == false) {
			manager.getTransaction().begin();
			manager.persist(schedule);
			manager.getTransaction().commit();
			manager.close();
			EntityManagerUtil.shutdown();
			return "Schedule Added Sucessfully";
		} else
			throw new MyException("Schedule is already exist");
	}

	@Override
	public String deleteSchedule(int scheduledProgramId) {
		manager=EntityManagerUtil.getEntityManagerFactory().createEntityManager();
		count = 0;
		for (Applicant app : manager.createQuery("SELECT a FROM Applicant a", Applicant.class).getResultList()) {
			if (app.getCourse().getCourseId() == scheduledProgramId) {
				count++;
			}
		}
		if(count==0)
		{
			Schedule sech = manager.find(Schedule.class, scheduledProgramId);
			if (sech != null) {
				manager.getTransaction().begin();
				manager.remove(sech);
				manager.getTransaction().commit();
				manager.close();
				EntityManagerUtil.shutdown();
				return "Schedule deleted sucessfully";
			}
			else {
				throw new MyException("There is no Schedule for this Schedule Program Id");
			}
		}
		else {
			throw new MyException("Cannot delete schedule because Some Students are already enroll in that course");
		}
	}

	@Override
	public List<Courses> viewCourses() {
		manager=EntityManagerUtil.getEntityManagerFactory().createEntityManager();
		courseList=manager.createQuery("SELECT a FROM Courses a", Courses.class).getResultList();
		manager.close();
		EntityManagerUtil.shutdown();
		return courseList;
	}

	@Override
	public List<Schedule> viewSchedule() {
		manager=EntityManagerUtil.getEntityManagerFactory().createEntityManager();
		scheduleList= manager.createQuery("SELECT a FROM Schedule a", Schedule.class).getResultList();
		manager.close();
		EntityManagerUtil.shutdown();
		return scheduleList;
	}

	@Override
	public String isValidId2(int id) {
		manager=EntityManagerUtil.getEntityManagerFactory().createEntityManager();
		for (Courses cour : manager.createQuery("SELECT a FROM Courses a", Courses.class).getResultList()) {
			if (cour.getCourseId() == id) {
				return cour.getProgramName();
			}
		}
		manager.close();
		EntityManagerUtil.shutdown();
		return null;

	}

	@Override
	public boolean isValidProgramName(String programName) {
		manager=EntityManagerUtil.getEntityManagerFactory().createEntityManager();
		for (Courses cour : manager.createQuery("SELECT a FROM Courses a", Courses.class).getResultList()) {
			if (cour.getProgramName().equalsIgnoreCase(programName)) {
				return true;
			}
		}
		manager.close();
		EntityManagerUtil.shutdown();
		return false;
	}

	@Override
	public String isValidScheduleProgramId(int scheduleProgramId) {
		manager=EntityManagerUtil.getEntityManagerFactory().createEntityManager();
		for (Schedule schedule : manager.createQuery("SELECT a FROM Schedule a", Schedule.class).getResultList()) {
			if (schedule.getScheduledProgramId() == scheduleProgramId) {
				return schedule.getProgramName();
			}
		}
		manager.close();
		EntityManagerUtil.shutdown();
		return null;
		
	}

	@Override
	public String updateSchedule(Schedule schedule) {
		manager=EntityManagerUtil.getEntityManagerFactory().createEntityManager();
		manager.getTransaction().begin();
	    manager.merge(schedule);
	    manager.getTransaction().commit();
	    manager.close();
		EntityManagerUtil.shutdown();
	    return "Schedule is updated";
	}

	
}
