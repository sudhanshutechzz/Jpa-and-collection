package com.cg.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.Schedule;
import com.cg.exception.MyException;

public class ApplicantdaoImpl implements Applicantdao {
	static int count = 4;
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
	EntityManager em = emf.createEntityManager();

	@Override
	public List<Courses> viewCourses() {

		return em.createQuery("SELECT a FROM Courses a", Courses.class).getResultList();
	}
	
	@Override
	public List<Schedule> viewSchedule() {
		// TODO Auto-generated method stub
		return em.createQuery("SELECT a FROM Schedule a",Schedule.class).getResultList();
	}

	@Override
	public Applicant applyForCourse(Applicant applicant) {
		Applicant applicant1 = new Applicant(0, applicant.getFullName(), applicant.getDateOfBirth(),
				applicant.getHighestQualification(), applicant.getMarksObtained(), applicant.getGoals(),
				applicant.getEmailId(), applicant.getCourse(), "under process", "Not yet finalised");

		em.getTransaction().begin();
		em.persist(applicant1);
		em.getTransaction().commit();
		return applicant1;
	}

	@Override
	public Applicant viewStatus(int appId) {
		
		boolean flag = false;

		
		Applicant app = new Applicant();

		List<Applicant> list = em.createQuery("select a from Applicant a", Applicant.class).getResultList();
		Iterator<Applicant> itr = list.iterator();
		while (itr.hasNext()) {
			app = itr.next();
			if (app.getApplicantId() == appId) {

				em.refresh(app);
				flag = true;
				break;

			}

		}
		if (flag == true) {
			return app;
		} else
			throw new MyException("List does not contain that id");

	}

	@Override
	public boolean isValidId(int id) {
		for (Courses cour : em.createQuery("SELECT a FROM Courses a", Courses.class).getResultList()) {
			if (cour.getCourseId() == id) {
				return true;
			}
		}
		return false;

	}


	
}
