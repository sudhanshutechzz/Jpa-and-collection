package com.cg.UI;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.bind.ValidationException;

import com.cg.service.ApplicantServiceImpl;
import com.cg.service.MACService;
import com.cg.service.MACServiceImpl;
import com.cg.Validation.UniversityAdmissionValidation;
import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.Schedule;
import com.cg.exception.MyException;
import com.cg.service.AdminService;
import com.cg.service.AdminServiceImpl;
import com.cg.service.ApplicantService;

public class MainUI {

	public static void main(String args[]) {
		Logger log=Logger.getLogger("org.hibernate");
		log.setLevel(Level.OFF);
		ApplicantService appser = new ApplicantServiceImpl();
		MACService mser = new MACServiceImpl();
		AdminService admin = new AdminServiceImpl();
		UniversityAdmissionValidation uav = new UniversityAdmissionValidation();
		String user;
		String adminUsername, adminPassword, macUsername, macPassword;
		boolean adminDecide, macDecide;
		String choice, fullName = "", date = "", highestQualification = "";
		float marksObtained = 0f;
		String emailId = "";
		String goals;
		int applicantId = 0;
		int courseId = 0;
		int status;
		int duration = 0, sessionsPerWeek = 0, scheduleProgramId = 0;
		String programName = null, description = null, degree = null, location = null, endDate = null, startDate = null,
				applicantEligibility = null;

		Scanner sc = new Scanner(System.in);
		System.out.println("**********************Welcome to University Admission System*************************");
		do {
			try {
				System.out.println("1. For Applicant");
				System.out.println("2. For MAC");
				System.out.println("3. For Admin");
				System.out.println("4. Exit");
				System.out.println("Enter your Choice");
				user = sc.next();
				switch (user) {
				case "1":
					boolean applicantForm = true;
					while (applicantForm) {
						System.out.println("1. View the courses");
						System.out.println("2. View the Schedule");
						System.out.println("3. Apply for the courses");
						System.out.println("4. View the status");
						System.out.println("5. for Exit");
						choice = sc.next();
						boolean flagApplicant = true;
						switch (choice) {

						case "1":
							List<Courses> list = appser.viewCourses();
							System.out.println(String.format("%-15s%-15s%-30s%-25s%-15s%-15s", "CourseId",
									"ProgramName", "description", "applicant_eligibility", "duration",
									"degree_certificate_offered"));
							for (Courses course : list) {
								System.out.println(String.format("%-15s%-15s%-30s%-25s%-15d%-15s", course.getCourseId(),
										course.getProgramName(), course.getDescription(),
										course.getApplicantEligibility(), course.getDuration(),
										course.getDegreeCertificateOffered()));
							}
							System.out.println("Make a note of courseId for applying for a course");
							break;
						
						case "2":
							List<Schedule> scheduleList = appser.viewSchedule();
							System.out.println(String.format("%-20s%-30s%-15s%-20s%-20s%-20s",
									"Scheduled_program_id", "ProgramName", "Location", "start_date", "end_date",
									"sessions_per_week"));
							for (Schedule schedule : scheduleList) {
								System.out.println(String.format("%-20s%-30s%-15s%-20s%-20s%-20d",
										schedule.getScheduledProgramId(), schedule.getProgramName(),
										schedule.getLocation(), schedule.getStartDate().toString(),
										schedule.getEndDate().toString(), schedule.getSessionsPerWeek()));
							}
							break;

						case "3":

							do {
								try {
									System.out.println("Enter your full name");
									if (flagApplicant == true)
										sc.nextLine();
									flagApplicant = false;
									fullName = sc.next();
									if (!uav.isValidName(fullName)) {
										System.err.println("Enter valid Name");
										flagApplicant = true;
									}
								} catch (InputMismatchException e) {
									System.err.println("Enter valid name");
									flagApplicant = true;
								}
							} while (flagApplicant);

							do {
								try {
									System.out.println("Enter the date of birth in format mm/dd/yyyy");
									if (flagApplicant == true)
										sc.nextLine();
									flagApplicant = false;
									date = sc.next();

									if (!uav.isValidDate(date)) {
										System.err.println("Enter valid Date");
										flagApplicant = true;
									}
								} catch (InputMismatchException e) {
									System.err.println("Enter valid Date");
									flagApplicant = true;
								}
							} while (flagApplicant);

							do {
								try {
									System.out.println("Enter the highest qualification in HSC/SSC/Graduation");
									if (flagApplicant == true)
										sc.nextLine();
									flagApplicant = false;
									highestQualification = sc.next();

									if (!uav.isValidHighestQualification(highestQualification)) {
										System.err.println("Enter valid highest Qualification");
										flagApplicant = true;
									}
								} catch (InputMismatchException e) {
									System.err.println("Enter valid highest Qualification");
									flagApplicant = true;
								}
							} while (flagApplicant);

							do {
								try {
									System.out.println("Enter the marks obtained in percentage");
									if (flagApplicant == true)
										sc.nextLine();
									flagApplicant = false;
									marksObtained = sc.nextFloat();

									if (!uav.isValidMarks(marksObtained)) {
										System.err.println("Enter valid marks in range 40 to 100");
										flagApplicant = true;
									}
								} catch (InputMismatchException e) {
									System.err.println("Enter valid marks in range 40 to 100");
									flagApplicant = true;
								}
							} while (flagApplicant);

							System.out.println("Enter the goals");
							goals = sc.next();

							do {
								try {
									System.out.println("Enter the email id");
									if (flagApplicant == true)
										sc.nextLine();
									flagApplicant = false;
									emailId = sc.next();

									if (!uav.isValidEmail(emailId)) {
										System.err.println("Enter valid email id");
										flagApplicant = true;
									}
								} catch (InputMismatchException e) {
									System.err.println("Enter valid email id");
									flagApplicant = true;
								}
							} while (flagApplicant);

							do {
								try {
									System.out.println("Enter the course id");
									if (flagApplicant == true)
										sc.nextLine();
									flagApplicant = false;
									courseId = sc.nextInt();

									if (!appser.isValidId(courseId)) {
										System.err.println("Course id does not exist");
										flagApplicant = true;
									}
								} catch (InputMismatchException e) {
									System.err.println("Enter valid course id");
									flagApplicant = true;
								}
							} while (flagApplicant);
							List<Courses> list1 = appser.viewCourses();
							Courses course = new Courses();
							for(Courses cour:list1)
							{
								if(cour.getCourseId()==courseId)
									{course=cour;
									break;}
							}
							Applicant app = appser.applyForCourse(fullName, date, highestQualification, marksObtained,
									goals, emailId, course);
							System.out.println(String.format("%-20s%-25s%-15s%-25s%-20s%-20s%-35s%-25s%-15s%-15s",
									"Application_id", "full_name", "date_of_birth", "highest_qualification",
									"marks_obtained", "goals", "email_id", "Scheduled_program_id", "status",
									"Date_Of_Interview"));
							System.out.println(String.format("%-20d%-25s%-15s%-25s%-20f%-20s%-35s%-25d%-15s%-15s",
									app.getApplicantId(), app.getFullName(), app.getDateOfBirth(),
									app.getHighestQualification(), app.getMarksObtained(), app.getGoals(),
									app.getEmailId(), app.getCourse().getCourseId(), app.getStatus(),
									app.getDateOfInterview()));
							break;

						case "4":
							do {
								try {
									System.out.println("Enter the Applicant id");
									if (flagApplicant == true)
										sc.nextLine();
									flagApplicant = false;
									applicantId = sc.nextInt();
								} catch (InputMismatchException e) {
									System.err.println("Enter valid applicant id");
									flagApplicant = true;
								}
							} while (flagApplicant);
							try
							{
							Applicant app2 = appser.viewStatus(applicantId);
							
								System.out.println(String.format("%-20s%-25s%-15s%-25s%-20s%-20s%-35s%-25s%-15s%-15s",
										"Application_id", "full_name", "date_of_birth", "highest_qualification",
										"marks_obtained", "goals", "email_id", "Scheduled_program_id", "status",
										"Date_Of_Interview"));
								System.out.println(String.format("%-20d%-25s%-15s%-25s%-20f%-20s%-35s%-25d%-15s%-15s",
										app2.getApplicantId(), app2.getFullName(), app2.getDateOfBirth(),
										app2.getHighestQualification(), app2.getMarksObtained(), app2.getGoals(),
										app2.getEmailId(), app2.getCourse(), app2.getStatus(),
										app2.getDateOfInterview()));
							}
							catch(MyException e)
							{
								System.out.println(e.getMessage());
							}
							break;

						case "5":
							applicantForm = false;
							break;

						default:
							System.out.println("Wrong Choice.Enter the Choice Again");
							applicantForm = true;
							break;
						}
					}
					break;

//Mac LAyer					
				case "2":
					System.out.println("Enter the username");
					macUsername = sc.next();
					System.out.println("Enter the password");
					macPassword = sc.next();
					try
					{
					macDecide = mser.verifyUser(macUsername, macPassword, "mac");
					if (macDecide == true) {
						boolean macForm = true;
						while (macForm) {
							System.out.println("Enter your choice");
							System.out.println("1: View Courses: ");
							System.out.println("2: Get Applicants by Course ID: ");
							System.out.println("3: Schedule Interview: ");
							System.out.println("4: Update Status of the Application: ");
							System.out.println("5: For Exit");
							choice = sc.next();
							boolean flagMac = true;
							switch (choice) {

							case "1":
								List<Courses> list = appser.viewCourses();
								System.out.println(String.format("%-15s%-15s%-30s%-25s%-15s%-15s", "CourseId",
										"ProgramName", "description", "applicant_eligibility", "duration",
										"degree_certificate_offered"));
								for (Courses course : list) {
									System.out.println(String.format("%-15s%-15s%-30s%-25s%-15d%-15s",
											course.getCourseId(), course.getProgramName(), course.getDescription(),
											course.getApplicantEligibility(), course.getDuration(),
											course.getDegreeCertificateOffered()));
								}
								System.out.println("Make a note of courseId for applying for a course");
								break;

							case "2":

								do {
									try {
										System.out.println("Enter Course ID :");
										if (flagMac == true)
											sc.nextLine();
										flagMac = false;
										courseId = sc.nextInt();
									} catch (InputMismatchException e) {
										System.err.println("Enter valid Course id");
										flagMac = true;
									}
								} while (flagMac);

								List<Applicant> list1 = new ArrayList<Applicant>();
								try
								{
								list1 = mser.getApplicantsByCourseId(courseId);
								
									for (Applicant app : list1) {
										System.out.println(
												String.format("%-20s%-25s%-15s%-25s%-20s%-20s%-35s%-25s%-15s%-15s",
														"Application_id", "full_name", "date_of_birth",
														"highest_qualification", "marks_obtained", "goals", "email_id",
														"Scheduled_program_id", "status", "Date_Of_Interview"));
										System.out.println(
												String.format("%-20d%-25s%-15s%-25s%-20f%-20s%-35s%-25d%-15s%-15s",
														app.getApplicantId(), app.getFullName(), app.getDateOfBirth(),
														app.getHighestQualification(), app.getMarksObtained(),
														app.getGoals(), app.getEmailId(), app.getCourse(),
														app.getStatus(), app.getDateOfInterview()));
									}
								}
								catch(MyException e)
								{
									System.out.println(e.getMessage());
								}
								break;

							case "3":
								do {
									try {
										System.out.println("Enter the Applicant id");
										if (flagMac == true)
											sc.nextLine();
										flagMac = false;
										applicantId = sc.nextInt();
									} catch (InputMismatchException e) {
										System.err.println("Enter valid applicant id");
										flagMac = true;
									}
								} while (flagMac);

								do {
									try {
										System.out.println("Enter the date of interview in format mm/dd/yyyy");
										if (flagMac == true)
											sc.nextLine();
										flagMac = false;
										date = sc.next();

										if (!uav.isValidDate(date)) {
											System.err.println("Enter valid Date");
											flagMac = true;
										}
									} catch (InputMismatchException e) {
										System.err.println("Enter valid Date");
										flagMac = true;
									}
								} while (flagMac);
								try
								{
								System.out.println(mser.sheduleInterview(applicantId, date));
								}
								catch(MyException e)
								{
									System.out.println(e.getMessage());
								}
								break;

							case "4":
								do {
									try {
										System.out.println("Enter the Applicant id");
										if (flagMac == true)
											sc.nextLine();
										flagMac = false;
										applicantId = sc.nextInt();
									} catch (InputMismatchException e) {
										System.err.println("Enter valid applicant id");
										flagMac = true;
									}
								} while (flagMac);

								System.out.println("Enter Status: 1. Selected 2. Rejected 3. On-Hold ");
								status = sc.nextInt();
								try
								{
								System.out.println(mser.updateStatus(applicantId, status));
								}
								catch(MyException e)
								{
									System.out.println(e.getMessage());
								}
								break;

							case "5":
								macForm = false;
								break;

							default:
								System.out.println("Wrong Choice. Enter the Choice Again");
								macForm = true;
								break;
							}
						}
					} 
					}
					catch(MyException e)
					{
						System.out.println(e.getMessage());
					}
					break;

//Admin Layer					
				case "3":
					System.out.println("Enter the username");
					adminUsername = sc.next();
					System.out.println("Enter the password");
					adminPassword = sc.next();
					try {
						adminDecide = admin.verifyUser(adminUsername, adminPassword, "admin");
						if (adminDecide == true) {
							boolean adminForm = true;
							while (adminForm) {
								System.out.println("Enter your choice");
								System.out.println("1. View Applicant");
								System.out.println("2. View Courses");
								System.out.println("3. Add Course");
								System.out.println("4. Delete Course ");
								System.out.println("5. Add Shedule ");
								System.out.println("6. Delete Schedule");
								System.out.println("7. View Schedules");
								System.out.println("8. Update Schedule");
								System.out.println("9. for Exit");
								choice = sc.next();
								boolean flagAdmin1 = true, flagAdmin2 = true, flagAdmin = true;
								switch (choice) {
								case "1":
									do {
										try {
											System.out.println("Enter the programName");
											if (flagAdmin2 == true)
												sc.nextLine();
											flagAdmin2 = false;
											programName = sc.next();
											if (admin.isValidProgramName(programName) == false) {
												System.err.println("Program name is not in the list");
												flagAdmin2 = true;
											}

										} catch (InputMismatchException e) {
											System.err.println("Program name is not in the list");
											flagAdmin2 = true;
										}
									} while (flagAdmin2);
									try
									{
										List<Applicant> list = admin.viewApplicant(programName);
										System.out.println(String.format("%-20s%-25s%-15s%-25s%-20s%-20s%-35s%-25s%-15s%-15s",
												"Application_id", "full_name", "date_of_birth", "highest_qualification",
												"marks_obtained", "goals", "email_id", "Scheduled_program_id", "status",
												"Date_Of_Interview"));
										for(Applicant applicant: list)
										{	
										    System.out.println(String.format("%-20d%-25s%-15s%-25s%-20f%-20s%-35s%-25d%-15s%-15s",
												applicant.getApplicantId(), applicant.getFullName(), applicant.getDateOfBirth(),
												applicant.getHighestQualification(), applicant.getMarksObtained(), applicant.getGoals(),
												applicant.getEmailId(), applicant.getCourse().getCourseId(), applicant.getStatus(),
												applicant.getDateOfInterview()));
										}
										
									}
									catch(MyException e)
									{
										System.out.println(e.getMessage());
									}
									break;
									
								case "2":
									List<Courses> list = admin.viewCourses();
									System.out.println(String.format("%-15s%-15s%-30s%-25s%-15s%-15s", "CourseId",
											"ProgramName", "description", "applicant_eligibility", "duration",
											"degree_certificate_offered"));
									for (Courses course : list) {
										System.out.println(String.format("%-15s%-15s%-30s%-25s%-15d%-15s",
												course.getCourseId(), course.getProgramName(), course.getDescription(),
												course.getApplicantEligibility(), course.getDuration(),
												course.getDegreeCertificateOffered()));
									}
									break;

								case "3":
									do {
										try {
											System.out.println("Enter the programName");
											if (flagAdmin2 == true)
												sc.nextLine();
											flagAdmin2 = false;
											programName = sc.next();
											if (admin.isValidProgramName(programName) == true) {
												System.err.println("Program is already in the list");
												flagAdmin2 = true;
											}

										} catch (InputMismatchException e) {
											System.err.println("Program is already in the list");
											flagAdmin2 = true;
										}
									} while (flagAdmin2);

									do {
										try {
											System.out.println("Enter Description");
											if (flagAdmin2 == true)
												sc.nextLine();
											flagAdmin2 = false;
											description = sc.next();
											if (!uav.isValidDescription(description)) {
												System.err.println("Enter first character in description capital");
												flagAdmin2 = true;
											}
										} catch (InputMismatchException e) {
											System.err.println("Enter first character in description capital");
											flagAdmin2 = true;
										}
									} while (flagAdmin2);
									
									

									while (flagAdmin1) {
										System.out.println("Enter Application Eligibility");
										System.out.println("Enter 1 for SSC");
										System.out.println("Enter 2 for HSC");
										System.out.println("Enter 3 for graduation");
										String opt = sc.next();

										switch (opt) {
										case "1":
											applicantEligibility = "SSC";
											flagAdmin1 = false;
											break;
										case "2":
											applicantEligibility = "HSC";
											flagAdmin1 = false;
											break;
										case "3":
											applicantEligibility = "Graduation";
											flagAdmin1 = false;
											break;
										default:
											System.out.println("Invalid Choice. Please Enter 1/2/3");
											flagAdmin1 = true;
											break;
										}
									}

									do {
										try {
											System.out.println("Enter duration");
											if (flagAdmin2 == true)
												sc.nextLine();
											flagAdmin2 = false;
											duration = sc.nextInt();

											if (!uav.isValidDuration(duration)) {
												System.err.println("Enter Duration  between 2 to 5 years");
												flagAdmin2 = true;
											}
										} catch (InputMismatchException e) {
											System.err.println("Enter Duration  between 2 to 5 years");
											flagAdmin2 = true;
										}
									} while (flagAdmin2);

									
									do {
										try {
											System.out.println("Enter Degree Certificate offered");
											if (flagAdmin2 == true)
												sc.nextLine();
											flagAdmin2 = false;
											degree = sc.next();

											if (!uav.isValidDegree(degree)) {
												System.err.println("Enter first character in degree capital");
												flagAdmin2 = true;
											}
										} catch (InputMismatchException e) {
											System.err.println("Enter first character in degree capital");
											flagAdmin2 = true;
										}
									} while (flagAdmin2);
									
									try {
										System.out.println(String.format("%-15s%-15s%-30s%-25s%-15s%-15s", "CourseId",
												"ProgramName", "description", "applicant_eligibility", "duration",
												"degree_certificate_offered"));
										Courses course=admin.addCourse(programName, description,
												applicantEligibility, duration, degree);
										System.out.println(String.format("%-15s%-15s%-30s%-25s%-15d%-15s",
												course.getCourseId(), course.getProgramName(), course.getDescription(),
												course.getApplicantEligibility(), course.getDuration(),
												course.getDegreeCertificateOffered()));
										System.out.println("Course added sucessfully and make note of courseid because it will help to schedule the course and Make sure you also added schedule for the course");
									} catch (MyException e) {
										System.out.println(e.getMessage());
									}
									break;

								case "4":
									System.out.println("Enter the CourseId");
									courseId = sc.nextInt();
									try {
										System.out.println(admin.deleteCourse(courseId));
									} catch (MyException e) {
										System.out.println(e.getMessage());
									}
									break;

								case "5":

									do {
										try {
											System.out.println("Enter the Schedule Program ID");
											if (flagAdmin2 == true)
												sc.nextLine();
											flagAdmin2 = false;
											scheduleProgramId = sc.nextInt();

											if (admin.isValidId2(scheduleProgramId) == null) {
												System.err.println("Schedule id does not exist");
												flagAdmin2 = true;
											} else
												programName = admin.isValidId2(scheduleProgramId);

										} catch (InputMismatchException e) {
											System.err.println("Schedule id does not exist");
											flagAdmin2 = true;
										}
									} while (flagAdmin2);

									do {
										try {
											System.out.println("Enter Location");
											if (flagAdmin2 == true)
												sc.nextLine();
											flagAdmin2 = false;
											location = sc.next();

											if (!uav.isValidLocation(location)) {
												System.err.println("Enter first character in location capital");
												flagAdmin2 = true;
											}
										} catch (InputMismatchException e) {
											System.err.println("Enter first character in location capital");
											flagAdmin2 = true;
										}
									} while (flagAdmin2);
								
								
									do {
										try {
											System.out.println("Enter the start date in format mm/dd/yyyy");
											if (flagAdmin2 == true)
												sc.nextLine();
											flagAdmin2 = false;
											startDate = sc.next();

											if (!uav.isValidDate(startDate)) {
												System.err.println("Enter valid Date");
												flagAdmin2 = true;
											}
										} catch (InputMismatchException e) {
											System.err.println("Enter valid Date");
											flagAdmin2 = true;
										}
									} while (flagAdmin2);

									do {
										try {
											System.out.println("Enter the End date in format mm/dd/yyyy");
											if (flagAdmin2 == true)
												sc.nextLine();
											flagAdmin2 = false;
											endDate = sc.next();

											if (!uav.isValidDate(startDate)) {
												System.err.println("Enter valid Date");
												flagAdmin2 = true;
											}
										} catch (InputMismatchException e) {
											System.err.println("Enter valid Date");
											flagAdmin2 = true;
										}
									} while (flagAdmin2);
									
									
									do {
										try {
											System.out.println("Enter the no sessions per week");
											if (flagAdmin2 == true)
												sc.nextLine();
											flagAdmin2 = false;
											sessionsPerWeek = sc.nextInt();

											if (!uav.isValidSessions(sessionsPerWeek)) {
												System.err.println("Enter Sessions per week  between 5 to 7 years");
												flagAdmin2 = true;
											}
										} catch (InputMismatchException e) {
											System.err.println("Enter Sessions per week  between 5 to 7 years");
											flagAdmin2 = true;
										}
									} while (flagAdmin2);
									
									try {
										System.out.println(admin.addSchedule(scheduleProgramId, programName, location,
												startDate, endDate, sessionsPerWeek));
									} catch (MyException e) {
										System.out.println(e.getMessage());
									}
									break;

								case "6":
									System.out.println("Enter Scheduled_program_id");
									scheduleProgramId = sc.nextInt();
									try {
										System.out.println(admin.deleteSchedule(scheduleProgramId));
									} catch (MyException e) {
										System.out.println(e.getMessage());
									}
									break;

								case "7":
									List<Schedule> scheduleList = admin.viewSchedule();
									System.out.println(String.format("%-20s%-30s%-15s%-20s%-20s%-20s",
											"Scheduled_program_id", "ProgramName", "Location", "start_date", "end_date",
											"sessions_per_week"));
									for (Schedule schedule : scheduleList) {
										System.out.println(String.format("%-20s%-30s%-15s%-20s%-20s%-20d",
												schedule.getScheduledProgramId(), schedule.getProgramName(),
												schedule.getLocation(), schedule.getStartDate().toString(),
												schedule.getEndDate().toString(), schedule.getSessionsPerWeek()));
									}
									break;
								case "8":
									do {
										try {
											System.out.println("Enter the Schedule Program ID");
											if (flagAdmin2 == true)
												sc.nextLine();
											flagAdmin2 = false;
											scheduleProgramId = sc.nextInt();

											if (admin.isValidScheduleProgramId(scheduleProgramId) == null) {
												System.err.println("Schedule for that Schedule id does not exist");
												flagAdmin2 = true;
											} else
												programName = admin.isValidId2(scheduleProgramId);

										} catch (InputMismatchException e) {
											System.err.println("Schedule id does not exist");
											flagAdmin2 = true;
										}
									} while (flagAdmin2);

									do {
										try {
											System.out.println("Enter Location");
											if (flagAdmin2 == true)
												sc.nextLine();
											flagAdmin2 = false;
											location = sc.next();

											if (!uav.isValidLocation(location)) {
												System.err.println("Enter first character in location capital");
												flagAdmin2 = true;
											}
										} catch (InputMismatchException e) {
											System.err.println("Enter first character in location capital");
											flagAdmin2 = true;
										}
									} while (flagAdmin2);
								
								
									do {
										try {
											System.out.println("Enter the start date in format mm/dd/yyyy");
											if (flagAdmin2 == true)
												sc.nextLine();
											flagAdmin2 = false;
											startDate = sc.next();

											if (!uav.isValidDate(startDate)) {
												System.err.println("Enter valid Date");
												flagAdmin2 = true;
											}
										} catch (InputMismatchException e) {
											System.err.println("Enter valid Date");
											flagAdmin2 = true;
										}
									} while (flagAdmin2);

									do {
										try {
											System.out.println("Enter the End date in format mm/dd/yyyy");
											if (flagAdmin2 == true)
												sc.nextLine();
											flagAdmin2 = false;
											endDate = sc.next();

											if (!uav.isValidDate(startDate)) {
												System.err.println("Enter valid Date");
												flagAdmin2 = true;
											}
										} catch (InputMismatchException e) {
											System.err.println("Enter valid Date");
											flagAdmin2 = true;
										}
									} while (flagAdmin2);
									
									
									do {
										try {
											System.out.println("Enter the no sessions per week");
											if (flagAdmin2 == true)
												sc.nextLine();
											flagAdmin2 = false;
											sessionsPerWeek = sc.nextInt();

											if (!uav.isValidSessions(sessionsPerWeek)) {
												System.err.println("Enter Sessions per week  between 5 to 7 years");
												flagAdmin2 = true;
											}
										} catch (InputMismatchException e) {
											System.err.println("Enter Sessions per week  between 5 to 7 years");
											flagAdmin2 = true;
										}
									} while (flagAdmin2);
									
									try {
										System.out.println(admin.updateSchedule(scheduleProgramId, programName, location,
												startDate, endDate, sessionsPerWeek));
									} catch (MyException e) {
										System.out.println(e.getMessage());
									}
									break;


								case "9":
									adminForm = false;
									break;
								default:
									System.out.println("Wrong Choice.Enter the Choice again");
									adminForm = true;
									break;
								}
							}
						}
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					break;

				case "4":
					System.exit(0);

				default:
					System.out.println("Invalid Choice. Please Enter 1/2/3/4");
				}
			}

			catch (InputMismatchException e) {
				System.err.println("Please enter a valid  choice");
				System.out.println(e);
			} catch (Exception e) {
				System.err.println("Please enter a valid  choice");
				System.out.println(e);
			}
		} while (true);
	}
}