package com.cg.service;

import java.util.List;
import com.cg.dao.Admindao;
import com.cg.dao.AdmindaoImpl;
import com.cg.dao.MACdao;
import com.cg.dao.MACdaoImpl;
import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.LogIn;
import com.cg.dto.Schedule;

public class AdminServiceImpl implements AdminService {

	Admindao admindao = new AdmindaoImpl();
	MACdao mdao = new MACdaoImpl();

	@Override
	public boolean verifyUser(String username, String password, String role) {
		return admindao.verifyUser(new LogIn(username, password, role));
	}
	
	@Override
	public List<Applicant> viewApplicant(String programName) {
		// TODO Auto-generated method stub
		return admindao.viewApplicant(programName);
	}

	@Override
	public Courses addCourse(String programName, String description, String applicantEligibility, int duration,
			String degreeCertificateOffered) {
		// TODO Auto-generated method stub

		return admindao.addCourse(
				new Courses(programName, description, applicantEligibility, duration, degreeCertificateOffered));
	}

	@Override
	public String deleteCourse(int courseId) {
		// TODO Auto-generated method stub
		return admindao.deleteCourse(courseId);
	}

	@Override
	public String addSchedule(int scheduledProgramId, String programName, String location, String startDate,
			String endDate, int sessionsPerWeek) {
		// TODO Auto-generated method stub
		return admindao.addSchedule(
				new Schedule(scheduledProgramId, programName, location, startDate, endDate, sessionsPerWeek));
	}

	@Override
	public String deleteSchedule(int scheduledProgramId) {
		// TODO Auto-generated method stub
		return admindao.deleteSchedule(scheduledProgramId);
	}

	@Override
	public List<Courses> viewCourses() {
		// TODO Auto-generated method stub
		return admindao.viewCourses();
	}

	@Override
	public List<Schedule> viewSchedule() {
		// TODO Auto-generated method stub
		return admindao.viewSchedule();
	}

	@Override
	public String isValidId2(int id) {
		// TODO Auto-generated method stub
		return admindao.isValidId2(id);
	}

	@Override
	public boolean isValidProgramName(String programName) {
		// TODO Auto-generated method stub
		return admindao.isValidProgramName(programName);
	}
	
	@Override
	public String isValidScheduleProgramId(int scheduleProgramId) {
		// TODO Auto-generated method stub
		return admindao.isValidScheduleProgramId(scheduleProgramId);
	}
	
	@Override
	public String updateSchedule(int scheduledProgramId, String programName, String location, String startDate,
			String endDate, int sessionsPerWeek) {
		// TODO Auto-generated method stub
		return admindao.updateSchedule(
				new Schedule(scheduledProgramId, programName, location, startDate, endDate, sessionsPerWeek));
	}
}
