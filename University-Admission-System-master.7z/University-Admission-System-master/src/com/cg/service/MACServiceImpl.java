package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.dao.MACdao;
import com.cg.dao.MACdaoImpl;
import com.cg.dto.Applicant;
import com.cg.dto.LogIn;

public class MACServiceImpl implements MACService {
	MACdao mdao = new MACdaoImpl();

	public boolean verifyUser(String username, String password, String role) {
		return mdao.verifyUser(new LogIn(username, password, role));
	}

	@Override
	public List<Applicant> getApplicantsByCourseId(int courseId) {
		// TODO Auto-generated method stub
		return mdao.getApplicantsByCourseId(courseId);
	}

	@Override
	public String sheduleInterview(int applicantId, String dateOfInterview) {
		// TODO Auto-generated method stub
		return mdao.sheduleInterview(applicantId, dateOfInterview);
	}

	@Override
	public String updateStatus(int applicantId, int status) {
		// TODO Auto-generated method stub
		return mdao.updateStatus(applicantId, status);
	}

}
