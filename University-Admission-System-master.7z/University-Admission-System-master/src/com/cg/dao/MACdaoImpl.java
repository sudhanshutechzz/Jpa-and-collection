package com.cg.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.LogIn;
import com.cg.exception.MyException;

public class MACdaoImpl implements MACdao {

	@Override
	public boolean verifyUser(LogIn login) {

		Iterator<LogIn> itr = StacticDataBase.getLogin().iterator();
		while (itr.hasNext()) {
			LogIn obj = itr.next();

			if (login.getUserName().equals(obj.getUserName()) && login.getPassword().equals(obj.getPassword())
					&& login.getRole().equals(obj.getRole())) {
				return true;
			}

		}
		throw new MyException("Invalid Credentials");

	}

	@Override
	public List<Applicant> getApplicantsByCourseId(int courseId) {
		// TODO Auto-generated method stub
		boolean flag = false;

		List<Applicant> list1 = new ArrayList<Applicant>();
		List<Applicant> list = StacticDataBase.applicant;
		Iterator<Applicant> itr = list.iterator();
		while (itr.hasNext()) {
			Applicant app = itr.next();
			if (app.getScheduledProgramId() == courseId) {
				list1.add(app);
				flag = true;
			}

		}
		if (flag == true)
			return list1;
		else
			throw new MyException("list does not conatin any applicant record basis on this id");
	}

	@Override
	public String sheduleInterview(int applicantId, String dateOfInterview) {

		List<Applicant> list = StacticDataBase.applicant;
		Iterator<Applicant> itr = list.iterator();
		boolean flag = false;
		while (itr.hasNext()) {
			Applicant app = itr.next();

			if (app.getApplicantId() == applicantId) {
				{
					if (app.getStatus().equalsIgnoreCase("under process")) {
						app.setDateOfInterview(dateOfInterview);
						flag = true;
					} else
						return "Application is already processed";
				}

			}

		}
		if (flag) {

			return "Interview Scheduled";
		} else {
			throw new MyException("Applicant id is not found");
		}

	}

	@Override
	public String updateStatus(int applicantId, int status) {
		// TODO Auto-generated method stub
		String statusValue = "";
		List<Applicant> list = StacticDataBase.applicant;
		Iterator<Applicant> itr = list.iterator();
		while (itr.hasNext()) {
			Applicant app = itr.next();
			if (app.getApplicantId() == applicantId) {
				if (!app.getDateOfInterview().equalsIgnoreCase("not yet finalised")) {
					if (status == 1) {
						statusValue = "Selected";
					} else if (status == 2) {
						statusValue = "Rejected";
					} else {
						statusValue = "On-Hold";
					}
					app.setStatus(statusValue);
					return "Status Updated";
				} else
					throw new MyException("firstly schedule an interview");
			}
			
		}
		throw new MyException("Application does not Exists");
	}

}
