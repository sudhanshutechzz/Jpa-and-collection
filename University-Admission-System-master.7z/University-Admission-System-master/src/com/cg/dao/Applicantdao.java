package com.cg.dao;

import java.util.List;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.Schedule;

public interface Applicantdao {
	public List<Courses> viewCourses();
	public List<Schedule> viewSchedule();

	public Applicant applyForCourse(Applicant applicant);

	public Applicant viewStatus(int applicantId);

	public boolean isValidId(int id);
}
