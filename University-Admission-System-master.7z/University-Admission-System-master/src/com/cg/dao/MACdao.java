package com.cg.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.dto.Applicant;
import com.cg.dto.LogIn;

public interface MACdao {
	public boolean verifyUser(LogIn login);

	public List<Applicant> getApplicantsByCourseId(int courseId);

	public String sheduleInterview(int applicantId, String dateOfInterview);

	public String updateStatus(int applicantId, int status);

}
