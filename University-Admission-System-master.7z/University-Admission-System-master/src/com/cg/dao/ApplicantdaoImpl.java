package com.cg.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.Schedule;
import com.cg.exception.MyException;

public class ApplicantdaoImpl implements Applicantdao {
	static int count = 4;

	@Override
	public List<Courses> viewCourses() {

		return StacticDataBase.getCourses();
	}
	
	@Override
	public List<Schedule> viewSchedule()
	{
		return StacticDataBase.getSchedules();
	}

	@Override
	public Applicant applyForCourse(Applicant applicant) {
		Applicant applicant1 = new Applicant(count++, applicant.getFullName(), applicant.getDateOfBirth(),
				applicant.getHighestQualification(), applicant.getMarksObtained(), applicant.getGoals(),
				applicant.getEmailId(), applicant.getScheduledProgramId(), "under process", "Not yet finalised");
		List<Applicant> list = new ArrayList<Applicant>();
		list.add(applicant1);
		StacticDataBase.getApplicant().add(applicant1);
		return applicant1;
	}

	@Override
	public Applicant viewStatus(int applicantId) {

		for (Applicant app : StacticDataBase.getApplicant()) {
			if (app.getApplicantId() == applicantId) {
				return app;
			}
		}

		throw new MyException("List does not contain that id");

	}

	public boolean isValidId(int id) {
		for (Courses cour : StacticDataBase.getCourses()) {
			if (cour.getCourseId() == id) {
				return true;
			}
		}
		return false;

	}

}
