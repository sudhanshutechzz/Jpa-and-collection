package com.cg.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.LogIn;
import com.cg.dto.Schedule;
import com.cg.exception.MyException;

public class AdmindaoImpl implements Admindao {
	List<Courses> list;

	@Override
	public boolean verifyUser(LogIn login) {

		for (LogIn lg : StacticDataBase.getLogin()) {
			if (login.getUserName().equals(lg.getUserName()) && login.getPassword().equals(lg.getPassword())
					&& login.getRole().equals(lg.getRole())) {
				return true;
			}
		}
		throw new MyException("Invalid credentials");

	}
	
	@Override
	public List<Applicant> viewApplicant(String programName) {
		int id = 0;
		List<Applicant> appList=new ArrayList();
		for(Courses course:StacticDataBase.getCourses())
		{
			if(course.getProgramName().equalsIgnoreCase(programName))
				id=course.getCourseId();
		}
		for(Applicant applicant:StacticDataBase.getApplicant())
		{
			if(applicant.getScheduledProgramId()==id)
			{
				appList.add(applicant);
			}
		}
		if(!appList.isEmpty())
			return appList;
		else
			throw new MyException("No Applicant is enroll in that course");
		
	}


	@Override
	public Courses addCourse(Courses course) {
		int courseId;
		list = StacticDataBase.getCourses();
		Courses course2 = new Courses(list.size() + 1, course.getProgramName(), course.getDescription(),
				course.getApplicantEligibility(), course.getDuration(), course.getDegreeCertificateOffered());
		boolean flag = false;
		for (Courses cour : list) {
			if (course.getCourseId() == cour.getCourseId())
				flag = true;
		}

		if (flag != true) {
			StacticDataBase.getCourses().add(course2);
			return course2;
		} else
			throw new MyException("Course with courseId already exist in the list");

	}

	@Override
	public String deleteCourse(int courseId) {
		int count = 0;
		list = StacticDataBase.getCourses();
		List<Applicant> list1 = StacticDataBase.getApplicant();
		Iterator<Applicant> it = list1.iterator();
		Applicant app = new Applicant();
		while (it.hasNext()) {
			app = it.next();
			if (app.getScheduledProgramId() == courseId) {
				count++;
			}
		}
		if (count == 0) {
			Iterator<Courses> itr = list.iterator();
			Courses course = new Courses();
			boolean flag = false;
			while (itr.hasNext()) {
				course = itr.next();
				if (course.getCourseId() == courseId) {
					list.remove(course);
					flag = true;
					break;
				}
			}
			if (flag) {
				return "Course deleted sucessfully and Make sure you also deleted the schedule for the course";
			} else {
				throw new MyException("There is no course for this course Id");
			}
		} else {
			throw new MyException("Cannot delete this course because students are already enroll in it");
		}

	}

	@Override
	public String addSchedule(Schedule schedule) {
		boolean flag = false;
		List<Schedule> list1 = StacticDataBase.getSchedules();
		for (Schedule sched : list1) {
			if (schedule.getScheduledProgramId() == sched.getScheduledProgramId())
				flag = true;
		}
		if (flag == false) {
			StacticDataBase.getSchedules().add(schedule);
			return "Schedule Added Sucessfully";
		} else
			throw new MyException("Schedule is already exist");
	}

	@Override
	public String deleteSchedule(int scheduledProgramId) {
		int count=0;
		for(Applicant applicant:StacticDataBase.getApplicant())
		{
			if(applicant.getScheduledProgramId()==scheduledProgramId)
			{
				count++;
			}
		}
		if(count==0)
		{
			List<Schedule> list = StacticDataBase.getSchedules();
			Iterator<Schedule> itr = list.iterator();
			Schedule schedule = new Schedule();
			boolean flag = false;
			while (itr.hasNext()) {
				schedule = itr.next();
				if (schedule.getScheduledProgramId() == scheduledProgramId) {
					list.remove(schedule);
					flag = true;
					break;
				}
			}
			if (flag) {
				return "Schedule deleted sucessfully";
			} else {
				throw new MyException("There is no Schedule for this Schedule Program Id");
			}
		}
		else
		{
			throw new MyException("Cannot delete this course because students are already enroll in it");
		}
	}

	@Override
	public List<Courses> viewCourses() {
		// TODO Auto-generated method stub
		return StacticDataBase.getCourses();
	}

	@Override
	public List<Schedule> viewSchedule() {

		return StacticDataBase.schedules;
	}

	public String isValidId2(int id) {
		for (Courses cour : StacticDataBase.getCourses()) {
			if (cour.getCourseId() == id) {
				return cour.getProgramName();
			}
		}
		return null;

	}

	@Override
	public boolean isValidProgramName(String programName) {
		for (Courses cour : StacticDataBase.getCourses()) {
			if (cour.getProgramName().equalsIgnoreCase(programName)) {
				return true;
			}
		}

		return false;
	}
	
	@Override
	public String isValidScheduleProgramId(int scheduleProgramId)
	{
		for(Schedule schedule:StacticDataBase.getSchedules())
		{
			if(schedule.getScheduledProgramId()==scheduleProgramId)
			{
				return schedule.getProgramName();
			}
		}
		return null;
	}

	@Override
	public String updateSchedule(Schedule schedule1) {
		for(Schedule schedule:StacticDataBase.getSchedules())
		{
			if(schedule.getScheduledProgramId()==schedule1.getScheduledProgramId())
			{
				schedule.setLocation(schedule1.getLocation());
				schedule.setProgramName(schedule1.getProgramName());
				schedule.setStartDate(schedule1.getStartDate());
				schedule.setEndDate(schedule1.getEndDate());
				schedule.setSessionsPerWeek(schedule1.getSessionsPerWeek());
			}
		}
		return "Schedule Updated Successfully";
	}

	
}
