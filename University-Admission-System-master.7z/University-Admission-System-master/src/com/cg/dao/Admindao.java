package com.cg.dao;

import java.util.List;

import com.cg.dto.Applicant;
import com.cg.dto.Courses;
import com.cg.dto.LogIn;
import com.cg.dto.Schedule;

public interface Admindao {
	public boolean verifyUser(LogIn login);
	public List<Applicant> viewApplicant(String programName);
	public List<Courses> viewCourses();

	public Courses addCourse(Courses course);

	public String deleteCourse(int courseId);

	public String addSchedule(Schedule schedule);

	public String deleteSchedule(int scheduledProgramId);

	public List<Schedule> viewSchedule();

	public String isValidId2(int id);

	public boolean isValidProgramName(String programName);
	public String isValidScheduleProgramId(int scheduleProgramId);
	public String updateSchedule(Schedule schedule);
}
